const express = require("express")
const router = express.Router()

const{insertUser,updateUser,getUser,deleteUser} = require("../controller/demoController")

router.post('/addUser',insertUser)
router.put('/updateUser/:id',updateUser)
router.get('/userDetails',getUser)
router.delete('/deleteUser/:id',deleteUser)


module.exports=router;